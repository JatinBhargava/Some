package com.enduser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnduserApplicationTests {

	@Test
	void contextLoads() {
	}

}
